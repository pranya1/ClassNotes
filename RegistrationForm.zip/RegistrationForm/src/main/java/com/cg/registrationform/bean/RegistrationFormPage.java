package com.cg.registrationform.bean;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class RegistrationFormPage {
	
@FindBy(how=How.NAME,name="userid")
	WebElement userId;

@FindBy(how=How.ID,id="pwd")
WebElement password;

@FindBy(how=How.NAME,name="username")
WebElement name;

@FindBy(how=How.ID,id="addr")
WebElement address;

@FindBy(how=How.NAME,name="country")
WebElement country;

@FindBy(how=How.NAME,name="zip")
WebElement zipCode;

@FindBy(how=How.CLASS_NAME,className="Format")
WebElement email;

@FindBy(how=How.NAME,name="sex")
List<WebElement> gender;

@FindBy(how=How.NAME,name="en")
List<WebElement> english;

@FindBy(how=How.NAME,name="submit")
WebElement button;
@FindBy(how=How.NAME,name="desc")
WebElement about;



public void setAbout(String about) {
	this.about.sendKeys(about);
}


public void clickme() {
	button.click();
}


public void setUserId(String userId) {
	this.userId.clear();
	this.userId.sendKeys(userId);
}

public void setPassword(String password) {
	this.password.clear();
	this.password.sendKeys(password);
}

public void setName(String name) {
	this.name.clear();
	this.name.sendKeys(name);
}

public void setAddress(String address) {
	this.address.clear();
	this.address.sendKeys(address);
}

public void setCountry(String country) {
	this.country.sendKeys(country);
}

public void setZipCode(String zipCode) {
	this.zipCode.clear();
	this.zipCode.sendKeys(zipCode);
}

public void setEmail(String email) {
	this.email.clear();
	this.email.sendKeys(email);
}

public void setGender(int gender) {
	
	this.gender.get(gender).click();
}

public void setEnglish(int english) {
	this.english.get(english).click();;
}

public void setButtton(String button) {

	this.button.sendKeys(button);
}





}
