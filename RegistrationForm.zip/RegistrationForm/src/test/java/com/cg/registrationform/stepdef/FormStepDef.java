package com.cg.registrationform.stepdef;


import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;


import com.cg.registrationform.bean.RegistrationFormPage;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class FormStepDef {
	WebDriver driver;
	RegistrationFormPage registerPage;
	String title;

	@Before
	public void init() {
		//we are initializing the Chrome driver
		System.setProperty("webdriver.chrome.driver","mydriver\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		registerPage=new 	RegistrationFormPage();
		PageFactory.initElements(driver,registerPage);
	}
	@After
	public void finish() throws Exception {
		Thread.sleep(5000);
		driver.quit();
	}
	
//giving the path of the file
@Given("^Registration form for validation$")
public void registration_form_for_validation() throws Throwable {
	driver.get("file:///C:/Users/VSURAMPA/Desktop/WebPages/RegistrationForm.html");
}
//checking the for the title
@When("^Checking title of registration form$")
public void checking_title_of_registration_form() throws Throwable {
	title=driver.getTitle();
}
//it compares the title
@Then("^Title should be Welcome to JobsWorld$")
public void title_should_be_Welcome_to_JobsWorld() throws Throwable {
	 assertEquals(title,"Welcome to JobsWorld");
}
//when it presses on click button
@When("^Clicking on next button without entering user id$")
public void clicking_on_next_button_without_entering_user_id() throws Throwable {
	registerPage.clickme();
	Thread.sleep(2000);
}
//it compares the alert message with given message
@Then("^getting alert User Id should not be empty / length be between five to twelve$")
public void getting_alert_User_Id_should_not_be_empty_length_be_between_five_to_twelve() throws Throwable {
	 String actual=driver.switchTo().alert().getText();
	    String expected="User Id should not be empty / length be between 5 to 12";
	    assertEquals(expected, actual);
	    driver.switchTo().alert().dismiss();
}
//it checks the input what user gave
@When("^clicking on next while entering the userid not in the given range$")
public void clicking_on_next_while_entering_the_userid_not_in_the_given_range() throws Throwable {
   registerPage.setUserId("123");
   registerPage.clickme();
}
// it enters the user input
@When("^Clicking on next button without entering password$")
public void clicking_on_next_button_without_entering_password() throws Throwable {
	registerPage.setUserId("Varun123");
	registerPage.clickme();
	    Thread.sleep(1000);
}

@Then("^getting alert Password should not be empty / length be between seven to twelve$")
public void getting_alert_Password_should_not_be_empty_length_be_between_seven_to_twelve() throws Throwable {
	String actual=driver.switchTo().alert().getText();
    String expected="Password should not be empty / length be between 7 to 12";
    assertEquals(expected, actual);
    driver.switchTo().alert().dismiss();
}

@When("^clicking on next while entering the password not in the given range$")
public void clicking_on_next_while_entering_the_password_not_in_the_given_range() throws Throwable {
   registerPage.setPassword("erf");
   registerPage.clickme();
   Thread.sleep(2000);
}

@Then("^getting alert Password should not be empty / length be between$")
public void getting_alert_Password_should_not_be_empty_length_be_between() throws Throwable {
	String actual=driver.switchTo().alert().getText();
    String expected="Password should not be empty / length be between 7 to 12";
    assertEquals(expected, actual);
    driver.switchTo().alert().dismiss();
}

@When("^Clicking on next button without entering name$")
public void clicking_on_next_button_without_entering_name() throws Throwable {
	registerPage.setPassword("Varun@1234");
	registerPage.clickme();
	    Thread.sleep(1000);
}

@Then("^getting alert Name should not be empty and must have alphabet characters only$")
public void getting_alert_Name_should_not_be_empty_and_must_have_alphabet_characters_only() throws Throwable {
	String actual=driver.switchTo().alert().getText();
    String expected="Name should not be empty and must have alphabet characters only";
    assertEquals(expected, actual);
    driver.switchTo().alert().dismiss();
}

@When("^clicking on next while entering the name in numbers$")
public void clicking_on_next_while_entering_the_name_in_numbers() throws Throwable {
  registerPage.setName("123");
  registerPage.clickme();
  Thread.sleep(2000);
}

@When("^Clicking on next button without entering address$")
public void clicking_on_next_button_without_entering_address() throws Throwable {
registerPage.setName("Varun");
registerPage.clickme();
Thread.sleep(2000);
}

@Then("^getting alert User address must have alphanumeric characters only$")
public void getting_alert_User_address_must_have_alphanumeric_characters_only() throws Throwable {
	String actual=driver.switchTo().alert().getText();
    String expected="User address must have alphanumeric characters only";
    assertEquals(expected, actual);
    driver.switchTo().alert().dismiss();
}

@When("^clicking on next while entering the address in special characters$")
public void clicking_on_next_while_entering_the_address_in_special_characters() throws Throwable {
	  registerPage.setAddress("9-/9");
	  registerPage.clickme();
	  Thread.sleep(2000);
}

@When("^Clicking on next button without selecting the country$")
public void clicking_on_next_button_without_selecting_the_country() throws Throwable {
	registerPage.setAddress("saiNagar");
	registerPage.clickme();
	Thread.sleep(2000);
}

@Then("^getting alert Select your country from the list$")
public void getting_alert_Select_your_country_from_the_list() throws Throwable {
	String actual=driver.switchTo().alert().getText();
    String expected="Select your country from the list";
    assertEquals(expected, actual);
    driver.switchTo().alert().dismiss();
}

@When("^Clicking on next button without entering zipcode$")
public void clicking_on_next_button_without_entering_zipcode() throws Throwable {
registerPage.setCountry("Australia");
registerPage.clickme();
Thread.sleep(2000);
}

@Then("^getting alert ZIP code must have numeric characters only$")
public void getting_alert_ZIP_code_must_have_numeric_characters_only() throws Throwable {
	String actual=driver.switchTo().alert().getText();
    String expected="ZIP code must have numeric characters only";
    assertEquals(expected, actual);
    driver.switchTo().alert().dismiss();
}

@When("^clicking on next while entering the zipcode in alphabets$")
public void clicking_on_next_while_entering_the_zipcode_in_alphabets() throws Throwable {
  registerPage.setZipCode("acd");
  registerPage.clickme();
Thread.sleep(2000);
}

@When("^Clicking on next button without entering Emailid$")
public void clicking_on_next_button_without_entering_Emailid() throws Throwable {
 registerPage.setZipCode("500042");
 registerPage.clickme();
 Thread.sleep(2000);
}

@Then("^getting alert You have entered an invalid email address!$")
public void getting_alert_You_have_entered_an_invalid_email_address() throws Throwable {
	String actual=driver.switchTo().alert().getText();
    String expected="You have entered an invalid email address!";
    assertEquals(expected, actual);
    driver.switchTo().alert().dismiss();
}

@When("^clicking on next while entering the email in wrong format$")
public void clicking_on_next_while_entering_the_email_in_wrong_format() throws Throwable {
	 registerPage.setEmail("acd");
	  registerPage.clickme();
	Thread.sleep(2000);
}

@When("^Clicking on next button without selecting the gender$")
public void clicking_on_next_button_without_selecting_the_gender() throws Throwable {
	 registerPage.setEmail("varun@gmail.com");
	 registerPage.clickme();
	 Thread.sleep(2000);
}

@Then("^getting alert Please Select gender$")
public void getting_alert_Please_Select_gender() throws Throwable {
	String actual=driver.switchTo().alert().getText();
    String expected="Please Select gender";
    assertEquals(expected, actual);
    driver.switchTo().alert().dismiss();
}

@When("^Clicking on next button after filling all fields correctly$")
public void clicking_on_next_button_after_filling_all_fields_correctly() throws Throwable {
	 registerPage.setGender(0);
	 // registerPage.setEnglish(0);
	registerPage.setAbout("We are training in capgemini");
	  registerPage.clickme();
	
	Thread.sleep(2000);
}

@Then("^getting alert Your Registration with JobsWorld\\.com has successfully done plz check your registred email addres to activate your profile$")
public void getting_alert_Your_Registration_with_JobsWorld_com_has_successfully_done_plz_check_your_registred_email_addres_to_activate_your_profile() throws Throwable {
	String actual=driver.switchTo().alert().getText();
    String expected="Your Registration with JobsWorld.com has successfully done plz check your registred email addres to activate your profile";
    assertEquals(expected, actual);
    driver.switchTo().alert().dismiss();
	
}

	

}
