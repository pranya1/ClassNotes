package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.hibernate.QueryException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.Coupons;
import com.cg.service.IMerchantService;

@Controller
public class CapStoreController {
//	List<Coupons> promo=new ArrayList<>();
	List<String> promo=new ArrayList<>();
	
	@Autowired
	IMerchantService iMerchantService;
	
	
	@RequestMapping("/index")
	public String index(Model model) {
		iMerchantService.plp();
		return "index";
	}
	@RequestMapping("/promos")
	public String promo(Model model)
	{promo.add("ADD50");
	promo.add("FEST30");
	promo.add("CAP60");
	model.addAttribute("promo",promo);
	
		//promo.add(new Coupons(, couponNumber, expiryDate, discount));
		return "promos";
	}
	@RequestMapping("/details")
	public String details(Model model)
{
		model.addAttribute("sample",iMerchantService.showDetails());
	return "details";
		}
	
	

@RequestMapping("/myinventory")
public String inventory(Model model)

{
return "myinventory";
	}

@RequestMapping("/AddDiscount")
public String addDiscount(Model model)

{
return "addDiscount";
	}


@RequestMapping("/DeleteDiscounts")
public String deleteDiscounts(Model model)

{
return "deleteDiscounts";
	}


@RequestMapping("/SoldItems")
public String soldItems(Model model)

{
return "soldItems";
	}

@RequestMapping("/logout")
public String logout(Model model)

{
return "logout";
	}


	
	
	
	
	
}
