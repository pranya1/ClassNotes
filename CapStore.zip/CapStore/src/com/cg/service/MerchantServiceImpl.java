package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IMerchantDAO;
import com.cg.entities.Merchant;

@Service
@Transactional
public class MerchantServiceImpl implements IMerchantService {

	@Autowired
	IMerchantDAO iMerchantDAO;
	
	

	@Override
	public void plp() {
		iMerchantDAO.plp();
	}



	@Override
	public void viewInventory() {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void addProducts() {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void removeProduct() {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void addDiscount() {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void removeDiscount() {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void checkOrders() {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void promos() {
		// TODO Auto-generated method stub
		
	}



	@Override
	public Merchant showDetails() {
	
		return iMerchantDAO.showDetails();
	}

	
}
