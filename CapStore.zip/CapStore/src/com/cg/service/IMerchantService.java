package com.cg.service;

import java.util.List;

import com.cg.entities.Merchant;

public interface IMerchantService {

	// List<QueryAnswers> getall();
void plp();
public void viewInventory();
public void addProducts();
public void removeProduct();
public void addDiscount();
public void removeDiscount();
public void checkOrders();
public void promos();
public	Merchant showDetails();
}
